class Borg:
    
    """The Borg design pattern"""
    

        

class Singleton(Borg): 
    
    """The singleton class"""
   

